import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './App.css'; // Reuse main styles for now

const API_BASE_URL = 'http://localhost:8000';

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    const endpoint = isRegistering ? '/register' : '/login';
    
    try {
      // For Login: OAuth2PasswordRequestForm expects form-data 'username' and 'password'
      // For Register: JSON body
      let options = {};
      
      if (isRegistering) {
        options = {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password }),
        };
      } else {
        const formData = new FormData();
        formData.append('username', email);
        formData.append('password', password);
        options = {
          method: 'POST',
          body: formData,
        };
      }

      const response = await fetch(`${API_BASE_URL}${endpoint}`, options);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || 'Authentication failed');
      }

      // Save Token
      localStorage.setItem('token', data.access_token);
      
      // Redirect to Dashboard
      navigate('/dashboard');

    } catch (err) {
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="app-container" style={{ justifyContent: 'center', alignItems: 'center' }}>
      <div className="welcome-card" style={{ maxWidth: '400px', width: '100%' }}>
        <div className="welcome-header">
          <h2>{isRegistering ? 'Create Account' : 'Welcome Back'}</h2>
          <p className="welcome-description">
            {isRegistering ? 'Join AI Interview Coach today.' : 'Sign in to continue your progress.'}
          </p>
        </div>

        {error && <div className="alert alert-error">{error}</div>}

        <form onSubmit={handleSubmit} className="interview-form">
          <div className="form-field">
            <label className="field-label">Email</label>
            <input
              type="email"
              className="field-input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div className="form-field">
            <label className="field-label">Password</label>
            <input
              type="password"
              className="field-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button type="submit" className="btn btn-primary btn-large" disabled={isLoading}>
            {isLoading ? 'Processing...' : (isRegistering ? 'Sign Up' : 'Login')}
          </button>
        </form>

        <div style={{ marginTop: '20px', textAlign: 'center' }}>
          <button 
            className="btn-link"
            onClick={() => setIsRegistering(!isRegistering)}
            style={{ background: 'none', border: 'none', color: '#2563eb', cursor: 'pointer', textDecoration: 'underline' }}
          >
            {isRegistering ? 'Already have an account? Login' : "Don't have an account? Sign Up"}
          </button>
        </div>
      </div>
    </div>
  );
}

export default LoginPage;
