import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import './App.css';

const API_BASE_URL = 'http://localhost:8000';

function DashboardPage() {
  const [user, setUser] = useState(null);
  const [history, setHistory] = useState([]); // Mock data for now
  const navigate = useNavigate();

  useEffect(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/');
      return;
    }
    
    // Fetch User Profile & Analytics
    const fetchData = async () => {
        try {
            const response = await fetch(`${API_BASE_URL}/analytics`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (response.ok) {
                const data = await response.json();
                setHistory(data.history);
                setUser({ email: "Candidate", ...data }); // Add stats to user obj
            }
        } catch (e) {
            console.error("Failed to fetch analytics", e);
        }
    };
    
    fetchData();
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/');
  };

  const startNewInterview = () => {
    navigate('/interview');
  };

  return (
    <div className="app-container">
      <header className="app-header">
        <div className="header-wrapper">
          <div className="brand">
            <div className="brand-icon">AI</div>
            <h1>Dashboard</h1>
          </div>
          <button onClick={handleLogout} className="btn btn-secondary" style={{ padding: '8px 16px' }}>
            Logout
          </button>
        </div>
      </header>

      <main className="app-main" style={{ padding: '2rem', maxWidth: '1200px', margin: '0 auto' }}>
        
        {/* Welcome Section */}
        <div className="welcome-card" style={{ marginBottom: '2rem', textAlign: 'left' }}>
          <h2>Hello, {user?.email} 👋</h2>
          <p>Ready to ace your next interview? You're on a great streak!</p>
          <div style={{ marginTop: '1.5rem' }}>
            <button onClick={startNewInterview} className="btn btn-primary btn-large">
              Start New Practice Session
            </button>
          </div>
        </div>

        {/* Analytics Section */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '2rem' }}>
          
          {/* Chart Card */}
          <div className="welcome-card" style={{ textAlign: 'left' }}>
            <h3>Performance Trend</h3>
            <div style={{ height: '300px', marginTop: '1rem', width: '100%' }}>
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={history}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis domain={[0, 10]} />
                  <Tooltip />
                  <Line type="monotone" dataKey="score" stroke="#2563eb" strokeWidth={3} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Recent History Card */}
          <div className="welcome-card" style={{ textAlign: 'left' }}>
            <h3>Recent Sessions</h3>
            <div style={{ marginTop: '1rem', display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              {history.slice().reverse().map((item, idx) => (
                <div key={idx} style={{ 
                  padding: '1rem', 
                  border: '1px solid #eee', 
                  borderRadius: '8px',
                  display: 'flex', 
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}>
                  <div>
                    <div style={{ fontWeight: 'bold' }}>Senior Developer Role</div>
                    <div style={{ fontSize: '0.9rem', color: '#666' }}>{item.date}</div>
                  </div>
                  <div style={{ 
                    background: item.score >= 7 ? '#dcfce7' : '#fef9c3', 
                    color: item.score >= 7 ? '#166534' : '#854d0e',
                    padding: '4px 12px', 
                    borderRadius: '12px',
                    fontWeight: 'bold'
                  }}>
                    Score: {item.score}/10
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </main>
    </div>
  );
}

export default DashboardPage;
